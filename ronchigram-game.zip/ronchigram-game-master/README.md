# ronchigram-game

Requires MATLAB R2018b

To play, run ronchi_game.m in MATLAB. Results will be saved in ./game_results which will be created if it does not exist.